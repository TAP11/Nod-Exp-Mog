const mongoose=require("mongoose")
mongoose.connect('mongodb://localhost:27017/LIBRARY');
const Schema=mongoose.Schema

const signSchema=new Schema({

    

    fname:String,
    sname:String,
    email:String,
    userid:String,
    phoneno:String,
    password:String

});

var sEntrydata=mongoose.model('signdata',signSchema)

module.exports=sEntrydata;