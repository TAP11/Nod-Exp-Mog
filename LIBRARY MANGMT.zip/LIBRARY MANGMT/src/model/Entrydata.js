const mongoose=require("mongoose")
mongoose.connect('mongodb://localhost:27017/LIBRARY');
const Schema=mongoose.Schema

const BookSchema=new Schema({

    

    title:String,
    author:String,
    genre :String,
    image:String,
    aimage:String

});

var Entrydata=mongoose.model('bookdata',BookSchema)

module.exports=Entrydata;
