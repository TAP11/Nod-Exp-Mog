const express=require('express');
const logRouter=express.Router();
const sEntrydata=require('../model/sEntrydata');






logRouter.post('/check',  function(req, res){
   var l = {
         userid:req.body.userid,
        password:req.body.password
    }
    
    if((l.userid=="admin")&&(l.password=="admin")){
        res.redirect('/admin/Pro');

    }
    else{
    sEntrydata.findOne(l).then(function (data){
        if(data!=null){
            res.redirect('/user/Pro');
            

        }
            else
             {
             res.redirect('/log');
            
        }

    })}

});

logRouter.get('/',function(req,res){
    res.render("log",{nav:[{link:'/',name:'HOME'}],title:"LOG-IN"});
});
module.exports=logRouter;
