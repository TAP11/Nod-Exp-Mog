const express=require("express")
const adRouter=express.Router();
const Entrydata=require('../model/Entrydata');
const { model } = require("../model/Entrydata");

adRouter.get("/Pro",function(req,res){
    res.render("Pro",{nav:[{link:'/admin/books',name:'BOOKS'},{link:'/admin/authors',name:'AUTHORS'},{link:'/admin/addentry',name:'ADD-ENTRIES'}],p:"ADMIN"});
});


adRouter.get("/addentry",function(req,res){
    res.render("addentry",{nav:[{link:'/admin/Pro',name:'PROFILE'},{link:'/admin/books',name:'BOOKS'},{link:'/admin/authors',name:'AUTHORS'}]});
});

adRouter.get("/books",function(req,res){
    Entrydata.find()
    .then(function(books){
        res.render("books",{
            nav:[
                {link:'/admin/authors',name:'AUTHORS'},
                {link:'/admin/Pro',name:'PROFILE'}
            ],
            
            books,u:"admin",d:"display:inline"
        });
    });

    })

    
    adRouter.get('/books/:id',function(req,res){
        const id=req.params.id;
        Entrydata.findOne({_id:id})
        .then(function(sbook){
    
            res.render('book',{nav:[{link:'/admin/books',name:'BOOKS'},{link:'/admin/authors',name:'AUTHORS'},{link:'/admin/Pro',name:'PROFILE'}],sbook,});
    
        })
       
       });

          

    adRouter.get('/books/delete/:id',function(req,res){
        const id=req.params.id;
        Entrydata.deleteOne({_id:id})
        .then(function(){
            res.redirect('/admin/books');
        });
    
        
    
           
    
        });


        adRouter.get('/books/update/:id',function(req,res){
            const id=req.params.id;

            Entrydata.findOne({_id:id})
            .then(function(book){
                 res.render("upentry",{nav:[{link:'/admin/Pro',name:'PROFILE'},{link:'/admin/books',name:'BOOKS'},{link:'/admin/authors',name:'AUTHORS'}],book});
     
                
        
            })
           
            
        
               
        
            });



            adRouter.post('/books/update/add/:id',function(req,res){
                const id=req.params.id;
                
            
              

                    Entrydata.updateOne({_id:id}, 
                        {title:req.body.title,
                        author: req.body.author,
                        genre:req.body.genre,
                        image:req.body.image,
                        aimage:req.body.aimage},function(){ res.redirect('/admin/books');});
                   
                  
                   

                
                
               
            
        
                
            
                   
            
                });
            
       



    adRouter.get("/authors",function(req,res){
        Entrydata.find()
        .then(function(authors){
            res.render("authors",{nav:[{link:'/admin/books',name:'BOOKS'},{link:'/admin/Pro',name:'PROFILE'}],authors,u:"admin"});
        });
    
        })


        adRouter.get('/authors/:id',function(req,res){
            const id=req.params.id;
            Entrydata.findOne({_id:id})
            .then(function(author){
        
                res.render('author',{nav:[{link:'/admin/authors',name:'AUTHORS'},{link:'/admin/books',name:'BOOKS'},{link:'/admin/Pro',name:'PROFILE'}],author});
        
            })
           
           });

    



adRouter.post("/addentry/add",function(req,res){


    var item={

        title: req.body.title,
        author: req.body.author,
        genre:req.body.genre,
        image:req.body.image,
        aimage:req.body.aimage,
    }

    var book=Entrydata(item);
    book.save();
    res.redirect('/admin/books');
});


module.exports=adRouter;
