const express=require("express")
const usrRouter=express.Router();
const Entrydata=require('../model/Entrydata');


usrRouter.get("/Pro",function(req,res){
    res.render("Pro",{nav:[{link:'/user/books',name:'BOOKS'},{link:'/user/authors',name:'AUTHORS'}],p:"USER"});
});



usrRouter.get("/books",function(req,res){
    Entrydata.find()
    .then(function(books){
        res.render("books",{
            nav:[
                {link:'/user/authors',name:'AUTHORS'},
                {link:'/user/Pro',name:'PROFILE'}
            ],
            
            books,u:"user",d:"display:none"
        });
    });

    })

    usrRouter.get('/books/:id',function(req,res){
        const id=req.params.id;
        Entrydata.findOne({_id:id})
        .then(function(sbook){
    
            res.render('book',{nav:[{link:'/user/authors',name:'AUTHORS'},{link:'/user/Pro',name:'PROFILE'}],sbook,});
    
        })
       
       });


    usrRouter.get("/authors",function(req,res){
        Entrydata.find()
        .then(function(authors){
            res.render("authors",{nav:[{link:'/user/books',name:'BOOKS'},{link:'/user/Pro',name:'PROFILE'}],authors,u:"user"});
        });
    
        })

        usrRouter.get('/authors/:id',function(req,res){
            const id=req.params.id;
            Entrydata.findOne({_id:id})
            .then(function(author){
        
                res.render('author',{nav:[{link:'/user/books',name:'BOOKS'},{link:'/user/Pro',name:'PROFILE'}],author});
        
            })
           
           });


     
        


   

    


        
module.exports=usrRouter;