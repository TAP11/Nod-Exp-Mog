const express=require('express');
const sRouter=express.Router();


const sEntrydata=require('../model/sEntrydata');


sRouter.get('/',function(req,res){
    res.render("sign",{nav:[{link:'/',name:'HOME'}],title:'SIGN-UP'});
});

sRouter.post("/add",function(req,res){
   
    var newuser={

        fname: req.body.fname,
        sname: req.body.sname,
        email:req.body.email,
        userid:req.body.userid,
        phoneno:req.body.phoneno,
        password:req.body.password,
    }

    var user=sEntrydata(newuser);
    user.save();
    res.redirect('/log');
});





module.exports=sRouter;
