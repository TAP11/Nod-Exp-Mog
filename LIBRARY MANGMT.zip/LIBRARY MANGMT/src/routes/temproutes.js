const express=require('express');
const tempRouter = express.Router();

    var food = [
        { 
            title:"Tom and Jerry",
            genre:"Cartoon",
            img:"t.jpg",
            time:"Uploaded 2 seconds ago",
            author:"Joseph Barbera"
        },
        {
    
            
            title:"Harry Potter",
            author:"JK.Rowling ",
            genre:"Fantasy Fiction",
            img:"h.jpg",
            time:"Uploaded 10 minutes ago",
    
        },    
        {
            title:"Immortals Of Meluha",
            author:"Amish Tripathi",
            genre:" Fiction",
            img:"m.jpg",
            time:"Uploaded 15 minutes ago",
    
        },    
        {
    
            title:"Sherlock holmes",
            author:"Arthur Conan Doyle",
            genre:"Crime Fiction",
            img:"s.jpg",
            time:"Uploaded 1 Day  ago",   
               
        }  
    
    ]

     var nav = [
          {link:'/log',name:'LOG-IN'},
     {link:'/sign',name:'SIGN-UP'}
     ]
     
    

    tempRouter.get('/',function(req,res){
        res.render("TEMP",{
            nav,
            food,
       
        });
    });

 
module.exports = tempRouter;
