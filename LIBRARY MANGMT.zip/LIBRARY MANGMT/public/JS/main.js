
function validate()

{ 
    check(t); 

    function check(callback)
    {
        callback();
        
    } 

     function t()
     {
         window.location.href = "/log";
         
     }



}

