const express=require('express');

const app = new express();
const upload=require('express-fileupload') 



const tempRouter = require("./src/routes/temproutes");
const logRouter=require("./src/routes/logRouter");
const sRouter=require("./src/routes/sRouter");
const adRouter=require("./src/routes/adminRouter");
const usrRouter=require("./src/routes/userRoutes");

app.use(upload())//middleware
app.use(express.urlencoded({extended:true})); //middleware
app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views','./src/views');
app.use('/',tempRouter);
app.use('/log',logRouter);
app.use('/sign',sRouter);
app.use('/admin',adRouter);
app.use('/user',usrRouter);


app.listen(9000);

console.log("hello");